# cs207-FinalProject
`autodiff` 
by

**Group Name:** DFYS

**Group Number:** 12

**Group Member:**  Feiyu Chen, Yueting Luo, Yan Zhao

[![Build Status](https://travis-ci.org/D-F-Y-S/cs207-FinalProject.svg?branch=master)](https://travis-ci.org/D-F-Y-S/cs207-FinalProject)

[![Coverage Status](https://coveralls.io/repos/github/D-F-Y-S/cs207-FinalProject/badge.svg?branch=master)](https://coveralls.io/github/D-F-Y-S/cs207-FinalProject?branch=master)

[![Doc Status](https://readthedocs.org/projects/cs207-finalproject/badge/?version=latest)](https://cs207-finalproject.readthedocs.io/en/latest/?badge=latest)

See Getting Started and the full document hosted on Read the Docs [here](https://cs207-finalproject.readthedocs.io/en/latest/)

